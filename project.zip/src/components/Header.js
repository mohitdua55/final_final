// src/components/Header.js

import React from "react";

const Header = () => {
  return (
    <div className="header">
      {/* <button>Display</button> */}
      <div className="filter-options">
        {/* <div>Grouping: Status</div>
        <div>Ordering: Priority</div> */}
      </div>
    </div>
  );
};

export default Header;
